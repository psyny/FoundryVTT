export const MOD_ID = 'psyny-tools';
export const MOD_NAME = "Psyny's Tools";
export const MOD_CSS = `${MOD_ID}--`;