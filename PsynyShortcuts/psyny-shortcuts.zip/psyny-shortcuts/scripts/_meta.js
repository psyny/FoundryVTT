export const MOD_ID = 'psyny-shortcuts';
export const MOD_NAME = "Psyny's Shortcuts";
export const MOD_CSS = `${MOD_ID}--`;